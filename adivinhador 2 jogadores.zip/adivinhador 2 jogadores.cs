﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adivinhador
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" ADIVINHADOR ");
            Console.WriteLine(" * REGRAS *");
            Console.WriteLine("* TENTE DESCOBRIR A PALAVRA SECRETA COM O MENOR NUMERO DE TENTATIVAS *");

            string palavra1, palavra2, palavra3, palavra4, palavra5, palavra = ""
                , palavrachave = "";
            int seletor, jogador1 = 0, jogador2 = 0;

            Console.WriteLine("Jogador 1 Digite 5 Palavras");
            palavra1 = "" + Console.ReadLine();
            palavra2 = "" + Console.ReadLine();
            palavra3 = "" + Console.ReadLine();
            palavra4 = "" + Console.ReadLine();
            palavra5 = "" + Console.ReadLine();

            Random aleatoria = new Random();
            seletor = aleatoria.Next(4);
            Console.Clear();


            if (seletor == 0)
            {
                palavrachave = palavra1;
               
            }
            else if(seletor == 1)
            {
                palavrachave = palavra2;
            }
            
            else if (seletor == 2)
            {
                palavrachave = palavra3;


            }
            else if (seletor == 3)
            {
                palavrachave = palavra4;

            }
            else if (seletor == 4)
            {
                palavrachave = palavra5;

            }

            Console.WriteLine(seletor);
            
            do
            {
                Console.WriteLine("Jogador 2: Tente adivinhar a palavra chave");
                palavra = "" + Console.ReadLine();
                jogador2++;

            } while (palavra != palavrachave);
           
            Console.WriteLine("Acertou!");
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("Jogador 2 Digite 5 Palavras");
            palavra1 = "" + Console.ReadLine();
            palavra2 = "" + Console.ReadLine();
            palavra3 = "" + Console.ReadLine();
            palavra4 = "" + Console.ReadLine();
            palavra5 = "" + Console.ReadLine();

            Random aleatoria1 = new Random();
            seletor = aleatoria1.Next(4);
            Console.Clear();


            if (seletor == 0)
            {
                palavrachave = palavra1;
                
            }
            else if (seletor == 1)
            {
                palavrachave = palavra2;

            }

            else if (seletor == 2)
            {
                palavrachave = palavra3;


            }
            else if (seletor == 3)
            {
                palavrachave = palavra4;

            }
            else if (seletor == 4)
            {
                palavrachave = palavra5;

            }

            Console.WriteLine(seletor);

            do
            {
                Console.WriteLine("Jogador 1: Tente adivinhar a palavra chave");
                palavra = "" + Console.ReadLine();
                jogador1++;

            } while (palavra != palavrachave);

            Console.WriteLine("Acertou!");
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("Tentativas jogador 1: " + jogador1);
            Console.WriteLine("Tentativas jogador 2: " + jogador2);
           
            if (jogador1 < jogador2)
            {
                Console.WriteLine("Jogador 1 venceu com apenas " + jogador1 +
                    " tentativas.");
            }
            else if(jogador2 < jogador1)
            {
                Console.WriteLine("Jogador 2 venceu com apenas " + jogador2 +
                    " tentativas.");
            }
            else
            {
                Console.WriteLine("Emapte! Ambos jogadores tiveram o mesmo numero de tentativas");
            }
            Console.ReadKey();

        }
    }
}